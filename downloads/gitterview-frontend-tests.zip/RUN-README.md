# GITERVIEW 화면 테스트

FrontReact 저장소에 추가한 테스트와 설정입니다. 기존 package.json에는 test:frontend 스크립트만 추가됩니다.
`npm run test:frontend`로 실행합니다. React DOM/jsdom에서 화면을 렌더링하며 GitHub/API 경계를 모의 처리합니다.
8개 통과. 실제 GitHub 계정·외부 API·배포 브라우저까지 검증한 것은 아닙니다.
