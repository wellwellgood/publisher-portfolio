import { useEffect, useRef, useState } from "react";

function toChartUrl(base, code) {
  const url = new URL(base, typeof window !== "undefined" ? window.location.href : "http://localhost");
  url.pathname = "/ws";
  url.search = new URLSearchParams({ codes: code }).toString();
  url.protocol = url.protocol === "https:" || url.protocol === "wss:" ? "wss:" : "ws:";
  return url.toString();
}

function selectTick(message, code) {
  let value = message;
  if (value && typeof value === "object" && "data" in value) value = value.data;
  if (Array.isArray(value)) value = value.find(tick => tick && String(tick.code ?? tick.symbol ?? tick.ticker) === code);
  if (!value || typeof value !== "object") return null;
  if (value[code] && typeof value[code] === "object") value = value[code];
  const symbol = value.code ?? value.symbol ?? value.ticker;
  if (symbol != null && String(symbol) !== code) return null;
  const rawPrice = value.price ?? value.stck_prpr ?? value.trade_price ?? value.tp ?? value.prc ?? value.c;
  if (rawPrice == null || rawPrice === "" || typeof rawPrice === "boolean") return null;
  const price = Number(rawPrice);
  const rawTime = value.t ?? value.ts ?? value.time ?? value.timestamp;
  const t = rawTime == null ? Date.now() : Number(rawTime);
  if (!Number.isFinite(price) || !Number.isFinite(t) || t <= 0) return null;
  return { t, price };
}

export default function useChartStreams(wsBaseUrl, codes = [], { max = 240, reconnect = true } = {}) {
  const seriesRef = useRef(new Map());
  const [, setVersion] = useState(0);
  const codesKey = JSON.stringify([...new Set(codes.filter(Boolean).map(String))]);
  const limit = Number.isFinite(max) && max > 0 ? Math.floor(max) : 240;

  useEffect(() => {
    const wanted = new Set(JSON.parse(codesKey));
    const sessions = new Map();
    let disposed = false;
    for (const code of seriesRef.current.keys()) {
      if (!wanted.has(code)) seriesRef.current.delete(code);
    }
    for (const [code, points] of seriesRef.current) {
      if (points.length > limit) seriesRef.current.set(code, points.slice(-limit));
    }
    setVersion(version => version + 1);

    function open(code) {
      if (disposed || !wanted.has(code)) return;
      let socket;
      try { socket = new WebSocket(toChartUrl(wsBaseUrl, code)); }
      catch { return; }
      const session = { socket, retry: null };
      sessions.set(code, session);
      const active = () => !disposed && sessions.get(code) === session;
      socket.onmessage = event => {
        if (!active() || socket.readyState !== WebSocket.OPEN) return;
        try {
          const point = selectTick(JSON.parse(String(event.data || "{}")), code);
          if (!point) return;
          const points = seriesRef.current.get(code) || [];
          const last = points[points.length - 1];
          if (last && (point.t < last.t || point.price === last.price)) return;
          seriesRef.current.set(code, [...points, point].slice(-limit));
          setVersion(version => version + 1);
        } catch { /* Ignore malformed frames; keep the last valid series. */ }
      };
      socket.onclose = () => {
        if (!active() || !reconnect || session.retry !== null) return;
        session.retry = setTimeout(() => {
          session.retry = null;
          if (active()) open(code);
        }, 1000);
      };
    }
    if (wsBaseUrl) wanted.forEach(open);
    return () => {
      disposed = true;
      for (const { socket, retry } of sessions.values()) {
        if (retry !== null) clearTimeout(retry);
        socket.onmessage = null;
        socket.onclose = null;
        socket.onerror = null;
        try { socket.close(); } catch { /* Already closed. */ }
      }
      sessions.clear();
    };
  }, [wsBaseUrl, codesKey, limit, reconnect]);
  return seriesRef.current;
}
