import React from 'react';
import {act as legacyAct} from 'react-dom/test-utils';
const act=React.act||legacyAct;
import {createRoot} from 'react-dom/client';
import useChartStreams from './useChartStreams';
class FakeSocket {
 static instances=[]; static OPEN=1;
 constructor(url){this.url=url;this.readyState=1;FakeSocket.instances.push(this);}
 close(){this.readyState=3;this.onclose?.({code:1000});}
 emit(data){this.onmessage?.({data:typeof data==='string'?data:JSON.stringify(data)});}
 drop(){this.readyState=3;this.onclose?.({code:1006});}
}
let root,container,result;
const mount=(codes)=>act(()=>root.render(<Probe codes={codes}/>));
function Probe({codes}){result=useChartStreams('ws://localhost/ws',codes,{max:3});return <output>{JSON.stringify([...result])}</output>;}
beforeEach(()=>{jest.useFakeTimers();FakeSocket.instances=[];global.WebSocket=FakeSocket;container=document.createElement('div');document.body.appendChild(container);root=createRoot(container);});
afterEach(()=>{act(()=>root.unmount());container.remove();jest.clearAllTimers();jest.useRealTimers();});
test('switching symbol closes prior connection and removes its data',()=>{
 mount(['AAA']);const first=FakeSocket.instances[0];act(()=>first.emit({code:'AAA',price:10,t:100}));
 mount(['BBB']);expect(first.readyState).toBe(3);expect(FakeSocket.instances).toHaveLength(2);
 expect(result.has('AAA')).toBe(false);
});
test('late message from previous symbol cannot mutate new screen data',()=>{
 mount(['AAA']);const old=FakeSocket.instances[0].onmessage;mount(['BBB']);
 act(()=>old({data:JSON.stringify({code:'AAA',price:999,t:100})}));expect(result.has('AAA')).toBe(false);
});
test('disconnect reconnects exactly once and accepts fresh messages',()=>{
 mount(['AAA']);act(()=>FakeSocket.instances[0].drop());expect(jest.getTimerCount()).toBe(1);
 act(()=>jest.advanceTimersByTime(1000));expect(FakeSocket.instances).toHaveLength(2);
 act(()=>FakeSocket.instances[1].emit({code:'AAA',price:11,t:100}));expect(result.get('AAA')).toEqual([{t:100,price:11}]);
});
test('leaving during retry cancels the timer and creates no late connection',()=>{
 mount(['AAA']);act(()=>FakeSocket.instances[0].drop());act(()=>root.render(null));
 expect(jest.getTimerCount()).toBe(0);act(()=>jest.advanceTimersByTime(10000));expect(FakeSocket.instances).toHaveLength(1);
});
test('repeated screen entries leave only one connection and no cleanup timers',()=>{
 for(let i=0;i<5;i++){mount(['AAA']);act(()=>root.render(null));}
 mount(['BBB']);expect(FakeSocket.instances.filter(s=>s.readyState===1)).toHaveLength(1);expect(jest.getTimerCount()).toBe(0);
});
test('malformed and other-symbol messages cannot enter a subscribed series',()=>{
 mount(['AAA']);const ws=FakeSocket.instances[0];act(()=>{ws.emit('not json');ws.emit({price:null,t:100});ws.emit([{code:'BBB',price:20,t:101}]);ws.emit({code:'BBB',price:30,t:102});});
 expect(result.has('AAA')).toBe(false);
});
test('out-of-order timestamps do not move chart backwards',()=>{
 mount(['AAA']);const ws=FakeSocket.instances[0];act(()=>{ws.emit({price:20,t:200});ws.emit({price:10,t:100});});
 expect(result.get('AAA')).toEqual([{t:200,price:20}]);
});
test('bounded history and unchanged-price behavior remain explicit',()=>{
 mount(['AAA']);const ws=FakeSocket.instances[0];act(()=>{for(let i=1;i<=5;i++)ws.emit({price:i,t:i});ws.emit({price:5,t:6});});
 expect(result.get('AAA')).toEqual([{t:3,price:3},{t:4,price:4},{t:5,price:5}]);
});
