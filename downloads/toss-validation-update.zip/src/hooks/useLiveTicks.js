import { useEffect, useState } from "react";

export default function useLiveTicks(wsUrl, { codes = [], reconnect = true, pingInterval = 3000 } = {}) {
  const [ticks, setTicks] = useState({});
  const codesKey = JSON.stringify([...new Set(codes.filter(Boolean).map(String))]);
  useEffect(() => {
    const wanted = new Set(JSON.parse(codesKey));
    setTicks({});
    if (!wsUrl || !wanted.size) return;
    let disposed = false;
    let current = null;
    let retry = null;
    let heartbeat = null;
    const clearHeartbeat = () => { if (heartbeat !== null) clearInterval(heartbeat); heartbeat = null; };
    let url;
    try {
      const target = new URL(wsUrl, window.location.href);
      target.protocol = target.protocol === "https:" || target.protocol === "wss:" ? "wss:" : "ws:";
      target.searchParams.set("codes", [...wanted].join(","));
      url = target.toString();
    } catch { return; }
    function open() {
      if (disposed) return;
      let socket;
      try { socket = new WebSocket(url); } catch { return; }
      current = socket;
      const active = () => !disposed && current === socket;
      socket.onopen = () => {
        if (!active()) return;
        clearHeartbeat();
        if (pingInterval > 0) heartbeat = setInterval(() => {
          if (active() && socket.readyState === WebSocket.OPEN) {
            try { socket.send('{"type":"ping"}'); } catch { /* Connection is closing. */ }
          }
        }, pingInterval);
      };
      socket.onmessage = event => {
        if (!active() || socket.readyState !== WebSocket.OPEN) return;
        try {
          let value = JSON.parse(String(event.data || ""));
          if (value && typeof value === "object" && "data" in value) value = value.data;
          const entries = Array.isArray(value)
            ? value.filter(tick => tick && tick.code != null).map(tick => [String(tick.code), tick])
            : value && typeof value === "object" && value.code != null
              ? [[String(value.code), value]]
              : Object.entries(value || {});
          const next = {};
          for (const [code, tick] of entries) {
            if (!wanted.has(code) || !tick || typeof tick !== "object") continue;
            const raw = tick.ts ?? tick.t ?? tick.time ?? tick.timestamp;
            const ts = raw == null ? Date.now() : Number(raw);
            if (Number.isFinite(ts) && ts > 0) next[code] = { ...tick, ts };
          }
          if (!Object.keys(next).length) return;
          setTicks(previous => {
            const merged = { ...previous };
            for (const [code, tick] of Object.entries(next)) {
              if (!merged[code] || tick.ts >= merged[code].ts) merged[code] = tick;
            }
            return merged;
          });
        } catch { /* Invalid frames do not replace valid state. */ }
      };
      socket.onclose = () => {
        if (!active()) return;
        clearHeartbeat();
        if (reconnect && retry === null) retry = setTimeout(() => {
          retry = null;
          if (active()) open();
        }, 5000);
      };
    }
    open();
    return () => {
      disposed = true;
      if (retry !== null) clearTimeout(retry);
      clearHeartbeat();
      if (current) {
        current.onopen = null;
        current.onmessage = null;
        current.onclose = null;
        current.onerror = null;
        try { current.close(); } catch { /* Already closed. */ }
      }
    };
  }, [wsUrl, codesKey, reconnect, pingInterval]);
  return ticks;
}
