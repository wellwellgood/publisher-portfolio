import React from 'react';
import {act as legacyAct} from 'react-dom/test-utils';
const act=React.act||legacyAct;
import {createRoot} from 'react-dom/client';
import useLiveTicks from './useLiveTicks';
class FakeSocket {
 static instances=[];static OPEN=1;
 constructor(url){this.url=url;this.readyState=1;this.sent=[];FakeSocket.instances.push(this);}
 send(value){this.sent.push(value);}
 open(){this.onopen?.();}
 close(){this.readyState=3;this.onclose?.({code:1000});}
 drop(){this.readyState=3;this.onclose?.({code:1006});}
 emit(value){this.onmessage?.({data:typeof value==='string'?value:JSON.stringify(value)});}
}
let root,container,result;
function Probe({codes}){result=useLiveTicks('ws://localhost/live', {codes,pingInterval:100,reconnect:true});return <output>{JSON.stringify(result)}</output>;}
const mount=codes=>act(()=>root.render(<Probe codes={codes}/>));
beforeEach(()=>{jest.useFakeTimers();FakeSocket.instances=[];global.WebSocket=FakeSocket;container=document.createElement('div');document.body.appendChild(container);root=createRoot(container);});
afterEach(()=>{act(()=>root.unmount());container.remove();jest.clearAllTimers();jest.useRealTimers();});
test('uses caller URL and subscribed symbols',()=>{mount(['AAA']);expect(FakeSocket.instances[0].url).toBe('ws://localhost/live?codes=AAA');});
test('symbol switch clears old ticks and ignores captured late callback',()=>{
 mount(['AAA']);const old=FakeSocket.instances[0];act(()=>old.emit({AAA:{price:10,t:100}}));expect(result.AAA.price).toBe(10);
 const late=old.onmessage;mount(['BBB']);act(()=>late({data:JSON.stringify({AAA:{price:999,t:200}})}));
 expect(result).toEqual({});expect(old.readyState).toBe(3);
 act(()=>FakeSocket.instances[1].emit({BBB:{price:20,t:200},AAA:{price:99,t:200}}));expect(Object.keys(result)).toEqual(['BBB']);
});
test('disconnect clears heartbeat, reconnects once, and resumes heartbeat',()=>{
 mount(['AAA']);act(()=>FakeSocket.instances[0].open());expect(jest.getTimerCount()).toBe(1);
 act(()=>FakeSocket.instances[0].drop());expect(jest.getTimerCount()).toBe(1);
 act(()=>jest.advanceTimersByTime(5000));expect(FakeSocket.instances).toHaveLength(2);
 act(()=>FakeSocket.instances[1].open());act(()=>jest.advanceTimersByTime(100));expect(FakeSocket.instances[1].sent).toEqual(['{"type":"ping"}']);
});
test('leaving during reconnect leaves no timer or new connection',()=>{
 mount(['AAA']);act(()=>FakeSocket.instances[0].open());act(()=>FakeSocket.instances[0].drop());act(()=>root.render(null));
 expect(jest.getTimerCount()).toBe(0);act(()=>jest.advanceTimersByTime(10000));expect(FakeSocket.instances).toHaveLength(1);
});
test('re-entry closes all previous connections and old time cannot replace latest tick',()=>{
 for(let i=0;i<4;i++){mount(['AAA']);act(()=>FakeSocket.instances.at(-1).open());act(()=>root.render(null));}
 mount(['BBB']);const current=FakeSocket.instances.at(-1);act(()=>{current.emit('broken json');current.emit({BBB:{price:20,t:200}});current.emit({BBB:{price:10,t:100}});});
 expect(FakeSocket.instances.filter(s=>s.readyState===1)).toHaveLength(1);expect(result.BBB.price).toBe(20);expect(jest.getTimerCount()).toBe(0);
});
