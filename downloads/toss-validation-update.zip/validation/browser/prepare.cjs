const fs=require('fs');const path=require('path');
for(const [source,target] of [['useChartStreams.js','chart.js'],['useLiveTicks.js','ticks.js']]){
 let code=fs.readFileSync(path.join(__dirname,'../../src/hooks',source),'utf8');
 code=code.replace('import { useEffect, useRef, useState } from "react";','').replace('import { useEffect, useState } from "react";','').replace('export default function','function');
 fs.writeFileSync(path.join(__dirname,target),code);
}
