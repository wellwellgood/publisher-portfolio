let root=ReactDOM.createRoot(document.getElementById('probe'));
let latest=null;
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function Chart({codes}){const series=useChartStreams('ws://127.0.0.1:8891/ws',codes);latest=Object.fromEntries(series);return React.createElement('pre',null,JSON.stringify(latest));}
function Ticks({codes}){latest=useLiveTicks('ws://127.0.0.1:8891/live',{codes,pingInterval:100});return React.createElement('pre',null,JSON.stringify(latest));}
const metrics=()=>fetch('/metrics').then(r=>r.json());
const render=async(mode,codes)=>{root.render(React.createElement(mode==='chart'?Chart:Ticks,{codes}));await pause(250);};
const leave=async()=>{root.render(null);await pause(100);};
const records=[];
function record(mode,scenario,passed,evidence){records.push({mode,scenario,passed,evidence});document.getElementById('results').textContent=JSON.stringify(records,null,2);if(!passed)throw Error(scenario);}
document.getElementById('run').onclick=async()=>{
 const button=document.getElementById('run');button.disabled=true;document.getElementById('status').textContent='실행 중';
 try{
 for(const mode of ['chart','ticks']){
  document.getElementById('status').textContent=mode+' 검증 중';
  await render(mode,['AAA']);let m=await metrics();record(mode,'최초 데이터 수신',!!latest.AAA&&m.active===1,{...m,keys:Object.keys(latest)});
  await render(mode,['BBB']);m=await metrics();record(mode,'종목 전환 후 이전 데이터·연결 제거',!!latest.BBB&&!latest.AAA&&m.active===1,{...m,keys:Object.keys(latest)});
  const before=m.opened;await fetch('/disconnect',{method:'POST'});await pause(mode==='chart'?1500:5500);m=await metrics();record(mode,'강제 연결 끊김 후 단일 재연결 및 수신',m.active===1&&m.opened===before+1&&!!latest.BBB,{...m,openedBefore:before});
  await leave();m=await metrics();record(mode,'화면 이탈 후 연결 0개',m.active===0,m);
  for(let i=0;i<3;i++){await render(mode,['AAA']);await leave();}
  await render(mode,['BBB']);m=await metrics();record(mode,'화면 3회 재진입 후 단일 연결',m.active===1&&!latest.AAA&&!!latest.BBB,{...m,keys:Object.keys(latest)});
  await fetch('/disconnect',{method:'POST'});await pause(100);await leave();const count=(await metrics()).opened;await pause(mode==='chart'?1300:5300);m=await metrics();record(mode,'재연결 대기 중 이탈 후 늦은 연결 없음',m.active===0&&m.opened===count,{...m,openedAfterLeave:count});
 }
 document.getElementById('status').textContent='완료: '+records.filter(r=>r.passed).length+'/'+records.length+' 통과';
 }catch(error){document.getElementById('status').textContent='실패: '+error.message;await leave();}
 button.disabled=false;
};
