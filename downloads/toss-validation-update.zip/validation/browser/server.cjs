const http=require('http');
const fs=require('fs');
const path=require('path');
const WS=require('ws');
const WebSocketServer=WS.WebSocketServer||WS.Server;
const root=__dirname;
let opened=0,closed=0;
const clients=new Set();
const server=http.createServer((req,res)=>{
 if(req.url==='/metrics'){res.setHeader('content-type','application/json');res.end(JSON.stringify({opened,closed,active:clients.size}));return;}
 if(req.url==='/disconnect'&&req.method==='POST'){for(const s of clients)s.terminate();res.end('ok');return;}
 const pathname=new URL(req.url,'http://localhost').pathname;
 let target;
 if(pathname==='/react.js')target=path.join(path.dirname(require.resolve('react/package.json')),'umd/react.development.js');
 else if(pathname==='/react-dom.js')target=path.join(path.dirname(require.resolve('react-dom/package.json')),'umd/react-dom.development.js');
 else target=path.join(root,pathname==='/'?'index.html':pathname.slice(1));
 if(!target.startsWith(root)&&!['/react.js','/react-dom.js'].includes(pathname)){res.writeHead(403);res.end();return;}
 res.setHeader('Content-Type',target.endsWith('.js')?'application/javascript':'text/html; charset=utf-8');
 fs.createReadStream(target).on('error',()=>{res.statusCode=404;res.end();}).pipe(res);
});
const wss=new WebSocketServer({server});
wss.on('connection',(socket,req)=>{
 opened++;clients.add(socket);let price=100;
 const code=new URL(req.url,'http://localhost').searchParams.get('codes')?.split(',')[0]||'AAA';
 const send=()=>{if(socket.readyState===1)socket.send(JSON.stringify({code,price:price++,t:Date.now()}));};
 send();const interval=setInterval(send,50);
 socket.on('close',()=>{clearInterval(interval);clients.delete(socket);closed++;});
});
server.listen(8891,'127.0.0.1',()=>console.log('WebSocket validation: http://127.0.0.1:8891'));
